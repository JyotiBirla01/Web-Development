import java.util.Scanner;

public class Jagged_Array {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter the rows of array ");
        int n = sc.nextInt();
        int arr[] = new int[n];
        System.out.println("Enter the elements in array ");
        int c = sc.nextInt();
        System.out.println("Enter the elements in array ");
        int d = sc.nextInt();
        System.out.println("Enter the elements in array ");
        int e = sc.nextInt();

    }

}
