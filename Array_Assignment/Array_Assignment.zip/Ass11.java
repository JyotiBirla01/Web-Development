import java.util.Scanner;

class Ass11 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int arr1[] = new int[100];
        int arr2[] = new int[50];
        arr1 = arr2;
        System.out.println(arr1.length);

    }
}