import java.util.Scanner;

public class Ass49 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the first number ");
        int firstNum = sc.nextInt();
        System.out.println("Enter the second number");
        int lastNum = sc.nextInt();
        int n = 0;
        int sum = 0;
        for (int i = firstNum; i <= lastNum; i++) {
            n = i;
            for (int j = 1; j <= (i / 2); j++) {
                if (i % j == 0) {
                    System.out.println(j);
                    sum = sum + j;

                }
            }
        }
        if (sum == n)
            System.out.println("Perfect");
        else
            System.out.println("Not perfect");

    }

}
