
import java.util.Scanner;

public class Ass15 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        for (char i = 97; i <= 122; i++) {
            System.out.println(i);
        }

    }
}
