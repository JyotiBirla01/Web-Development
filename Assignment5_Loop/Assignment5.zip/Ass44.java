import java.util.Scanner;

public class Ass44 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number ");
        int n = sc.nextInt();
        int rem, x;
        while (n != 0) {
            rem = n % 10;
            x = rem;
            break;

        }

    }

}
