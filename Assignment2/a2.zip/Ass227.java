//Write a Java program to input basic salary of an employee and calculate its Gross salary according to following:
// Basic Salary <= 10000 : HRA = 20%, DA = 80% 
//Basic Salary <= 20000 : HRA = 25%, DA = 90% 
//Basic Salary > 20000 : HRA = 30%, DA = 95% 

import java.util.Scanner;

public class Ass227 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your basic salary ");
        float basicSalary = sc.nextInt();
        if (basicSalary <= 10000) {
            System.out.println("HRA is " + basicSalary * (20 / 100f));
            System.out.println("DRA is " + basicSalary * (80 / 100f));
        } else if (basicSalary <= 20000) {
            System.out.println("HRA is " + basicSalary * (25 / 100f));
            System.out.println("DRA is " + basicSalary * (90 / 100f));
        } else if (basicSalary > 20000) {
            System.out.println("HRA is " + basicSalary * (30 / 100f));
            System.out.println("DRA is " + basicSalary * (95 / 100f));
        }
    }

}
