
//W.A.P to check the sign of given number. 
import java.util.Scanner;

class Ass217 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number :-");
        int num = sc.nextInt();
        if (num > 0)
            System.out.println("The sign is positive");
        else
            System.out.println("The sign is negative");

    }
}
