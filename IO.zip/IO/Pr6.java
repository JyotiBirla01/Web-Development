//Que. 6 Write a program to count number of bytes in a image file(jpeg/png/gif). Also find how
//much time it will take to upload the file on server if internet speed is 256 bps(bitsper
//second).
import java.io.File;
import java.io.FileWriter;
public class Pr6 {
    public static void main(String[] args) throws Exception  {
       
    File f= new File("davv.png");
    double internerSpeed=256;
    long fileSize= f.length();
    double uploadTime= (fileSize * 8)/internerSpeed;
    System.out.println(" File Size  "+ fileSize+ " bytes ");
System.out.println(" Upload time "+ uploadTime+ " sec ");
    }
    
}
