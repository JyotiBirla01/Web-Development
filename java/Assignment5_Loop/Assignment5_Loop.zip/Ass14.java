
import java.util.Scanner;

public class Ass14 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        for (char i = 65; i <= 90; i++) {
            System.out.println(i);
        }

    }

}
