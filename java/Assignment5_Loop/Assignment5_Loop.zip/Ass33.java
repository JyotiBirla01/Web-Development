
//WAP to print Alphabets in reversing order
import java.util.Scanner;

class Ass33 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        for (char i = 90; i >= 65; i--) {

            System.out.println(i);

        }
    }

}
