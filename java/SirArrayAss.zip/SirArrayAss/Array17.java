public class Array17 {
    public static void main(String[] args) {

    }

}
