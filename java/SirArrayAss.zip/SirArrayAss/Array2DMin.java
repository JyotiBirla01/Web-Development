public class Array2DMin {

}
