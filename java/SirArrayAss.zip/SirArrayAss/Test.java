class A {
    public static void main(String args[]) {
        System.out.println("uytr");
        for (;;) {

        }
        // System.out.println(b);
    }
}